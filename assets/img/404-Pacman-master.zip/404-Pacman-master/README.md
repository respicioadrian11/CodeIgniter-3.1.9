# A fun page 404
If the URL is broken, do not stress just throw a little pacman.


![alt tag](https://raw.githubusercontent.com/leonardoscorza/pacman/master/image/printscreen.jpg)

[Check out the demo](http://stormy-anchorage-6431.herokuapp.com/404.html)

# License

MIT licensed
